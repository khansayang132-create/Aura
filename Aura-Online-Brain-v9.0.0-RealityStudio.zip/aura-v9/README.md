# Aura Online Brain v2.3 Smart Operator

A stronger online version of Aura built on the existing web/PWA UI. It keeps the client-side app but adds a Node server as Aura's online brain layer.

## What is new

- Online model gateway using an OpenAI-compatible chat endpoint configured on the server.
- Server-side persistent memory in `data/memory.json`.
- Conversation-aware online chat.
- Live web search through the server.
- Health/status endpoint.
- API keys stay server-side; never put secrets in the browser.
- Existing PWA manifest/service worker retained.
- Existing Aura UI and local-first behavior retained as fallback.

## Run locally

Requires Node.js 18+.

```bash
npm start
```

Open:

`http://127.0.0.1:8787`

## Enable the online model

Copy `.env.example` to `.env` and set your provider's OpenAI-compatible endpoint and key. The included server reads environment variables; it intentionally does not load secrets into `www/`.

```text
AURA_MODEL_URL=https://YOUR_PROVIDER/v1/chat/completions
AURA_MODEL_KEY=YOUR_SECRET
AURA_MODEL_NAME=YOUR_MODEL
```

Then start the server with those variables in the environment.

## Deploying online

For a real phone-accessible Aura, deploy the whole project to a Node-capable host (for example a VPS or managed Node service). A static host such as GitHub Pages cannot run `server/server.mjs`, so it can only host the offline/browser-only PWA.

Use HTTPS in production.

## Security

- Never commit `.env` or API keys.
- Put authentication in front of a public deployment before sharing it broadly.
- The server intentionally does not expose environment variables to the browser.
- Treat web search results as untrusted external content.

## Reality check

“100x more powerful” is an engineering goal, not a measurable guarantee. This build adds the online infrastructure needed for substantially more capability, but the quality of reasoning still depends on the model endpoint you connect and the tools/data you authorize.

## Social Operator

Run one controlled social cycle:

```bash
./aura-social.sh "x,ig,tiktok" "ai tools for solo founders" "email list + $29/mo product"
```

The script first uses the local Aura Online Brain API at `AURA_URL` (default `http://127.0.0.1:8787`). If the server is unavailable, it falls back to the `llm` CLI when installed.

The online API requires `AURA_MODEL_URL` (and optionally `AURA_MODEL_KEY` / `AURA_MODEL_NAME`) on the server. The browser never receives the model key.

## Aura 2.2 Smart Brain

New deterministic intelligence layer:
- `/api/brain/status` — model, memory, conversation and signal status.
- `/api/brain/insights` — extracts audience-question, metric and repeated-theme signals from stored memory.
- `/api/social-plan` — produces an evidence-first five-step social experiment plan even when no model API is configured.
- Chat and successful online social cycles are persisted to `data/conversations.json`.
- Memory records support a `source` field so imported/user/analytics evidence can be distinguished.

Aura never treats missing metrics as zero and never fabricates a model response when the model endpoint is unavailable.


## v2.3 Smart Operator
- Adaptive cycle endpoint: `/api/adaptive-cycle`
- Brain recommendation endpoint: `/api/brain/recommendation`
- Real observation logging: `POST /api/experiment/log`
- Evidence-backed learning loop with explicit insufficient-evidence states
- Smart mobile-first operator UI with live brain state, adaptive cycles, learning capture, copy/save/clear, and insight refresh
- No fabricated metrics, audience demand, products, prices, links, or performance


## HyperCore v4.0 engineering memory
Aura now ships durable coding and graphics knowledge packs plus executable reviewers.
- `GET /api/knowledge/status`
- `GET /api/knowledge/search?q=...&domain=coding|graphics`
- `POST /api/brain/coding-review` with `{ "code": "..." }`
- `POST /api/brain/visual-review` with `{ "html": "..." }`
- `npm test` runs an end-to-end HyperCore smoke suite.

The packs are evidence/engineering guidance, not a claim that Aura has learned every programming framework or design system. Real project-specific knowledge still comes from the user's source, tests, and observations.

## Engineering memory packs
- `prompts/engineering/coding-engineer.md` — coding/release operating memory.
- `prompts/engineering/graphics-engineer.md` — visual/UI operating memory.
- `data/knowledge/coding.json` — 40 coding principles/checks.
- `data/knowledge/graphics.json` — 40 graphics/UI principles/checks.

## Engineering Omni v5
Aura now includes a broad engineering knowledge layer covering 30 domains and 240 reusable verification rules. The Engineering Omni cockpit is available at `/engineering.html` and exposes knowledge search, deep engineering review, and project-plan generation. These are decision-support checks, not proof of correctness; always run project-specific tests.

Engineering API:
- `GET /api/engineering/status`
- `GET /api/engineering/search?q=...`
- `POST /api/engineering/review`
- `POST /api/engineering/plan`


## OmniMind v6

OmniMind adds a model fabric rather than pretending one model is universally best. Configure one or more OpenAI-compatible endpoints with `AURA_MODEL_URL` or `AURA_MODELS` (JSON array of `{name,url,key,weight}`). Aura routes tasks by domain, fails over across configured models, and can synthesize independent candidate outputs. No model credentials are bundled. With zero configured models, deterministic Aura engines remain available and the API reports `MODEL_NOT_CONFIGURED`.

New endpoints: `/api/model/status`, `/api/model/route`, `/api/model/ensemble`. Visual cockpit: `/omnimind.html`.

Model outputs are advisory. Tests, source inspection, runtime behavior, and real-world evidence remain authoritative.

## v6.1.0 — Pro Max Vision System

The core brain is unchanged in capability, but the entire operator surface now has a dependency-free visual system layer:
- unified Aura navigation across Vision Hub, Operator, OmniMind and Engineering
- responsive desktop/tablet/mobile layouts
- persistent dark/light theme
- command center with Ctrl/Cmd+K and Escape handling
- keyboard-focusable controls and reduced-motion support
- visual system tokens, ambient grid, glass surfaces, responsive cards and mobile navigation
- new `vision.html` command hub
- PWA shortcuts for the main surfaces
- service-worker cache version bumped for the new visual assets

This is a UI/UX architecture upgrade, not a claim of a measurable increase in model intelligence. Model outputs remain advisory; source/runtime/test evidence remains authoritative.

## v6.2.0 — 100X ProMax Vision System

This release extends the visual layer across the entire product surface rather than adding decorative UI only. The root route is now the Vision Hub, with unified navigation, command center, system-state indicators, persistent appearance, responsive mobile navigation, keyboard shortcuts, reduced-motion support, accessible focus states, and live `/api/vision/status` telemetry. Existing deterministic, engineering, memory, search and OmniMind capabilities remain intact.
