#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PLATFORMS="${1:-x,ig,tiktok}"
NICHE="${2:-ai tools for solo founders}"
GOAL="${3:-email list + \$29/mo product}"
BASE_URL="${AURA_URL:-http://127.0.0.1:8787}"

printf '[aura] platforms: %s\n[aura] niche:     %s\n[aura] goal:       %s\n\n' "$PLATFORMS" "$NICHE" "$GOAL"

if command -v curl >/dev/null 2>&1; then
  if curl -fsS --max-time 3 "$BASE_URL/api/health" >/dev/null 2>&1; then
    echo '[aura] using Aura Online Brain API...'
    curl -fsS -X POST "$BASE_URL/api/social-cycle" \
      -H 'content-type: application/json' \
      --data-binary "$(python3 - <<PY
import json
print(json.dumps({'platforms':'$PLATFORMS','niche':'$NICHE','goal':'$GOAL'}))
PY
)"
    exit 0
  fi
fi

if command -v llm >/dev/null 2>&1; then
  echo '[aura] Aura server unavailable; using llm CLI...'
  llm -s "$(cat "$ROOT/prompts/social-operator.md")" \
    "Run one full social cycle. Platforms: $PLATFORMS. Niche: $NICHE. Goal: $GOAL.\nOutput: 1) 5 post ideas (hook + body + CTA + best time to post) 2) 3 reply templates 3) 1 lead magnet concept 4) 1 monetization step 5) metrics to check in 7 days 6) one thing to stop doing."
  exit 0
fi

echo '[aura] No Aura server and no llm CLI found.' >&2
echo "Start Aura with: cd \"$ROOT\" && npm start" >&2
echo 'Or install/configure an llm CLI.' >&2
exit 1
