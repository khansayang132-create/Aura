import assert from 'node:assert/strict';
import { ATLAS_VERSION, DOMAIN_COUNT, RULES_PER_DOMAIN, domainAt, domainById, rulesForDomain, findDomains } from '../server/domain-atlas.mjs';
assert.equal(ATLAS_VERSION,'8.0.0-1000000Domain');
assert.equal(DOMAIN_COUNT,1_000_000);
assert.equal(RULES_PER_DOMAIN,24);
assert.equal(DOMAIN_COUNT*RULES_PER_DOMAIN,24_000_000);
for (const i of [0,1,999999,543210]) { const d=domainAt(i); assert.ok(d?.domainId); assert.equal(rulesForDomain(d).length,24); assert.equal(domainById(d.domainId).index,i); }
assert.ok(findDomains('security production',10).length>0);
console.log(JSON.stringify({ok:true,atlasVersion:ATLAS_VERSION,domains:DOMAIN_COUNT,rules:DOMAIN_COUNT*RULES_PER_DOMAIN,rulesPerDomain:RULES_PER_DOMAIN,search:'pass'}));
