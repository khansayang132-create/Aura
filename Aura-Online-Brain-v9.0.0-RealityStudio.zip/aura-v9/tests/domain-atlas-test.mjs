import fs from 'node:fs/promises';
const p=new URL('../data/knowledge/engineering.json',import.meta.url);
const rows=JSON.parse(await fs.readFile(p,'utf8'));
const domains=new Set(rows.map(x=>x.domain));
if(domains.size!==1000) throw new Error(`Expected 1000 domains, got ${domains.size}`);
if(rows.length!==24000) throw new Error(`Expected 24000 rules, got ${rows.length}`);
for(const d of domains){ const n=rows.filter(x=>x.domain===d).length; if(n!==24) throw new Error(`${d}: expected 24 rules, got ${n}`);}
console.log(JSON.stringify({ok:true,materializedDomains:domains.size,materializedRules:rows.length,rulesPerDomain:24}));
