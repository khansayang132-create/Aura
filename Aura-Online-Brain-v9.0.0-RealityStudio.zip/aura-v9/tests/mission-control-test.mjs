import assert from 'node:assert/strict';
import http from 'node:http';
import {spawn} from 'node:child_process';
const port=8898; const child=spawn(process.execPath,['server/server.mjs'],{env:{...process.env,PORT:String(port),HOST:'127.0.0.1'}});
const get=p=>new Promise((resolve,reject)=>{const r=http.get(`http://127.0.0.1:${port}${p}`,res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>resolve({status:res.statusCode,json:()=>JSON.parse(s),body:s}));});r.on('error',reject)});
try{await new Promise(r=>setTimeout(r,250)); const h=await get('/api/health'); assert.equal(h.status,200); assert.equal(h.json().version,'9.0.0-RealityStudio'); const o=await get('/api/system/overview'); assert.equal(o.status,200); const d=o.json(); assert.equal(d.ok,true); assert.equal(d.checks.runtime.ok,true); assert.equal(d.checks.storage.ok,true); assert.equal(d.checks.protection.ok,true); const m=await get('/mission.html'); assert.equal(m.status,200); assert.match(m.body,/Mission Control/); console.log(JSON.stringify({ok:true,version:d.version,overall:d.overall,checks:Object.keys(d.checks).length,missionPage:true}));} finally {child.kill('SIGTERM')}
