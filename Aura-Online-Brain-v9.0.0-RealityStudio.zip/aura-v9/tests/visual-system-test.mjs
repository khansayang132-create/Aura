import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
for(const rel of ['aura-pro.css','aura-pro.js','vision.html','index.html','www/aura-pro.css','www/aura-pro.js','www/vision.html','manifest.json','www/manifest.json','sw.js']){
  const s=await fs.readFile(path.join(root,rel),'utf8'); assert.ok(s.length>300,`${rel} unexpectedly small`);
}
const css=await fs.readFile(path.join(root,'aura-pro.css'),'utf8');
for(const token of ['aura-pro-nav','aura-pro-top','aura-command-head','aura-toast','aura-system-strip','aura-hero-actions','prefers-reduced-motion','@media(max-width:620px)']) assert.match(css,new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')),`missing ${token}`);
const js=await fs.readFile(path.join(root,'aura-pro.js'),'utf8');
for(const token of ['Command Center','aura.theme','metaKey','aura-mobile-bar','/api/health','data-global-status']) assert.match(js,new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')),`missing ${token}`);
const html=await fs.readFile(path.join(root,'vision.html'),'utf8');
for(const token of ['100X ProMax Vision','Launch Operator','Command Center','data-state','data-model','Requirements','Verify']) assert.match(html,new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')),`missing ${token}`);
const manifest=JSON.parse(await fs.readFile(path.join(root,'manifest.json'),'utf8'));
assert.equal(manifest.start_url,'./index.html'); assert.equal(manifest.shortcuts.length,4);
console.log(JSON.stringify({ok:true,version:'9.0.0-RealityStudio',visualSystem:true,visionHub:true,rootIsVisionHub:true,responsive:true,commandCenter:true,theming:true,systemStatus:true,pwaShortcuts:manifest.shortcuts.length}));
