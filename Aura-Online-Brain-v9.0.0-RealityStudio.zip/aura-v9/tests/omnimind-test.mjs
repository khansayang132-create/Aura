import {spawn} from 'node:child_process';
const port=8897;
const env={...process.env,PORT:String(port),HOST:'127.0.0.1',AURA_MODELS:'[]'};
const p=spawn(process.execPath,['server/server.mjs'],{cwd:new URL('..',import.meta.url).pathname,env,stdio:['ignore','pipe','pipe']});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function get(path){const r=await fetch(`http://127.0.0.1:${port}${path}`);return [r.status,await r.json()];}
async function post(path,b){const r=await fetch(`http://127.0.0.1:${port}${path}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});return [r.status,await r.json()];}
try{
 await sleep(350);
 let [s,h]=await get('/api/health'); if(s!==200||!h.ok||h.version!=='9.0.0-RealityStudio') throw new Error('health/version');
 [s,h]=await get('/api/model/status'); if(s!==200||h.count!==0||h.router!=='OmniMind') throw new Error('model status');
 [s,h]=await post('/api/model/route',{task:'debug a Node API security issue'}); if(s!==503||h.ok!==false||h.route!=='engineering') throw new Error('route fallback');
 [s,h]=await post('/api/model/ensemble',{prompt:'Explain why tests matter'}); if(s!==503||h.ok!==false) throw new Error('ensemble fallback');
 [s,h]=await post('/api/engineering/plan',{goal:'build a secure mobile graphics dashboard'}); if(s!==200||!h.stages||h.stages.length!==7) throw new Error('engineering plan');
 console.log('OK OmniMind: routing, ensemble fallback, engineering plan, health');
} finally {p.kill('SIGTERM');}
