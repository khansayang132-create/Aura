import assert from "node:assert/strict";
import {spawn} from "node:child_process";
const port=8898, base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['server/server.mjs'],{cwd:new URL('..',import.meta.url).pathname,env:{...process.env,PORT:String(port),HOST:'127.0.0.1'},stdio:['ignore','pipe','pipe']});
async function wait(){for(let i=0;i<30;i++){try{const r=await fetch(base+'/api/health');if(r.ok)return;}catch{} await new Promise(r=>setTimeout(r,100));}throw new Error('server did not start');}
async function get(p){const r=await fetch(base+p); assert.equal(r.ok,true,`${p} ${r.status}`); return r.json();}
async function post(p,b){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)}); assert.equal(r.ok,true,`${p} ${r.status}`); return r.json();}
try{
 await wait();
 const page=await fetch(base+"/engineering.html"); assert.equal(page.status,200);
 const sw=await fetch(base+"/sw.js"); assert.equal(sw.status,200); const swText=await sw.text(); assert.match(swText,/engineering\.html/);
 const manifest=await fetch(base+"/manifest.json"); assert.equal(manifest.status,200);
 const h=await get("/api/health"); assert.equal(h.version,"9.0.0-RealityStudio");
 const s=await get("/api/engineering/status"); assert.ok(s.count>=200); assert.ok(s.domains.length>=20);
 const q=await get("/api/engineering/search?q=security%20testing"); assert.ok(q.results.length>0);
 const r=await post("/api/engineering/review",{source:"fetch('https://example.com',{signal:AbortSignal.timeout(4000)}); try { await x(); } catch(e) { console.error(e) } // test focus aria auth"}); assert.equal(typeof r.review.score,"number"); assert.ok(r.coding); assert.ok(r.visual);
 const p=await post("/api/engineering/plan",{goal:"build secure mobile PWA with offline support",context:"graphics accessibility testing deployment"}); assert.equal(p.stages.length,7); assert.ok(p.relevantKnowledge.length>0);
 const ms=await get('/api/model/status'); assert.equal(ms.router,'OmniMind');
 const bad=await fetch(base+"/api/engineering/review",{method:"POST",headers:{"content-type":"application/json"},body:"{}"}); assert.equal(bad.status,400);
 console.log(JSON.stringify({ok:true,version:h.version,knowledge:s.count,domains:s.domains.length,search:q.results.length,reviewScore:r.review.score,planStages:p.stages.length,modelRouter:ms.router}));
} finally {child.kill('SIGTERM');}
