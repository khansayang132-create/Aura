import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {spawn} from 'node:child_process';
const ROOT=new URL('..',import.meta.url); const port=8897; const base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['server/server.mjs'],{cwd:ROOT.pathname,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',AURA_RATE_MAX:'200'},stdio:['ignore','pipe','pipe']});
let logs=''; child.stdout.on('data',d=>logs+=d); child.stderr.on('data',d=>logs+=d);
async function get(p){const r=await fetch(base+p); const j=await r.json(); return {r,j};}
async function post(p,b){const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)}); const j=await r.json(); return {r,j};}
try{
  let ok=false; for(let i=0;i<30;i++){try{const x=await get('/api/health'); if(x.j.ok){ok=true;break}}catch{} await new Promise(r=>setTimeout(r,100));} assert(ok,'server did not start');
  const health=(await get('/api/health')).j; assert.equal(health.version,'9.0.0-RealityStudio');
  const ks=(await get('/api/knowledge/status')).j; assert(ks.domains.coding>=40); assert(ks.domains.graphics>=40); assert(ks.total>=80);
  const sr=(await get('/api/knowledge/search?q=network+timeout')).j; assert(sr.results.length>0);
  const cr=(await post('/api/brain/coding-review',{code:'fetch("http://example.com"); const apiKey="SECRET123";'})).j; assert(cr.ok); assert(cr.findings.some(x=>x[1].includes('secret')));
  const vr=(await post('/api/brain/visual-review',{html:'<html><body><img src="x.png"></body></html>'})).j; assert(vr.ok); assert(vr.findings.length>=2);
  const cyc=(await post('/api/cycle',{platforms:'ig,tiktok',niche:'Indonesian women fashion',goal:'real audience learning',tone:'direct'})); assert.equal(cyc.r.status,200); assert(cyc.j.text.length>200); assert(cyc.j.mode);
  const mem=(await get('/api/memory')).j; assert(Array.isArray(mem.items));
  const diag=(await get('/api/diagnostics')).j; assert(diag.api.includes('/api/brain/coding-review')); assert(diag.api.includes('/api/brain/visual-review'));
  const backup=(await get('/api/backup/export')).j; assert.equal(backup.schema,'aura-backup-v1'); assert(Array.isArray(backup.memory));
  const bad=await post('/api/cycle',{platforms:'',niche:'',goal:''}); assert.equal(bad.r.status,400);
  const opts=await fetch(base+'/api/health',{method:'OPTIONS'}); assert.equal(opts.status,204);
  const root=await fetch(base+'/'); assert.equal(root.status,200);
  const op=await fetch(base+'/operator.html'); assert.equal(op.status,200); const oph=await op.text(); assert(oph.includes('/api/cycle'));
  const sw=await fetch(base+'/sw.js'); assert.equal(sw.status,200);
  const manifest=JSON.parse(await (await fetch(base+'/manifest.json')).text()); assert.ok(manifest.name.startsWith('Aura Online Brain'));
  console.log(JSON.stringify({ok:true,version:health.version,knowledge:ks.total,memory:mem.items.length,cycleMode:cyc.j.mode,checks:'health+knowledge+search+code-review+visual-review+cycle+memory+diagnostics+backup'}));
} finally {child.kill('SIGTERM'); await new Promise(r=>setTimeout(r,100)); if(child.exitCode!==0 && child.exitCode!==null) console.error(logs);}
