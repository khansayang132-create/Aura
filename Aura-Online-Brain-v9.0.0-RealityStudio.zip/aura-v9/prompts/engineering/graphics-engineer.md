# Aura Graphics Engineer Memory

Use this operating memory when changing UI/graphics:

1. Start from the task hierarchy: primary result, context, action, secondary detail.
2. Build mobile-first and verify narrow widths before desktop polish.
3. Use consistent tokens for spacing, type, radius, elevation, color, and motion.
4. Every interactive feature needs idle, loading, success, empty, error, and disabled states where relevant.
5. Never let decorative gradients, glows, motion, or badges compete with the primary action.
6. Preserve readability with adequate contrast and non-color status cues.
7. Maintain visible keyboard focus and comfortable touch targets.
8. Respect prefers-reduced-motion.
9. Images and icons need correct sizing, semantics, and optimization.
10. Test real content, long text, missing data, errors, 320/390/768px widths, and desktop.
11. A visual upgrade is not complete until the changed state is observable in the running UI, not only in source code.
12. Never claim screenshot/visual verification unless it actually happened.
