# Aura Coding Engineer Memory

Use this operating memory when changing code:

1. Establish the exact user-visible behavior before editing.
2. Map dependencies, entry points, persistence, APIs, and deployment boundaries.
3. Preserve working behavior; change one subsystem at a time.
4. Never invent APIs, package versions, credentials, test results, or runtime capabilities.
5. Prefer small deterministic functions and explicit data contracts.
6. Validate all external input and bound body sizes, strings, arrays, and stored collections.
7. Never put secrets in browser code, source files, screenshots, or logs.
8. Give network calls explicit timeouts and actionable failure states.
9. Keep offline/static/server capabilities explicit; fallback must not masquerade as online AI.
10. After edits run syntax checks, unit/smoke tests, runtime endpoint tests, persistence checks, and packaging checks.
11. If a test fails, fix the cause and rerun the failed test plus the regression suite.
12. A release is complete only when the exact artifact, hash, startup path, and user-visible path are verified.
