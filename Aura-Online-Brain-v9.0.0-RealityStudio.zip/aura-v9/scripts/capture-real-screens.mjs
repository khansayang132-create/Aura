import {spawn} from 'node:child_process';
import {mkdirSync,existsSync} from 'node:fs';
import {join} from 'node:path';
const root=process.cwd(), out=join(root,'screenshots'); mkdirSync(out,{recursive:true});
const port=8787; const server=spawn(process.execPath,['server/server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),HOST:'127.0.0.1'},stdio:'ignore'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
try{
  await sleep(900);
  const pages=['/','/operator.html','/omnimind.html','/engineering.html','/mission.html','/showcase.html'];
  for(const page of pages){const name=page==='/'?'vision':page.slice(1,-5); const url=`http://127.0.0.1:${port}${page}`; const args=['--headless','--no-sandbox','--disable-gpu','--hide-scrollbars',`--window-size=1440,1000`,`--screenshot=${join(out,name+'.png')}`,url]; const p=spawn('chromium',args,{stdio:'ignore'}); const code=await new Promise(r=>p.on('close',r)); if(code!==0) throw new Error(`chromium failed for ${page}`); if(!existsSync(join(out,name+'.png'))) throw new Error(`missing screenshot ${page}`)}
  console.log(JSON.stringify({ok:true,screenshots:pages.length,out}));
}finally{server.kill('SIGTERM')}
