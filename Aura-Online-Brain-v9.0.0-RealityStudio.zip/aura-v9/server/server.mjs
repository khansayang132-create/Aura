import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { URL } from 'node:url';
import { ATLAS_VERSION, DOMAIN_COUNT as ATLAS_DOMAIN_COUNT, RULES_PER_DOMAIN, domainAt, domainById, findDomains, rulesForDomain, randomSample, taxonomy as ATLAS_TAXONOMY } from './domain-atlas.mjs';

const ROOT = path.resolve(new URL('..', import.meta.url).pathname);
const DATA = path.join(ROOT, 'data');
const WWW = ROOT;
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const CORS_ORIGIN = process.env.AURA_CORS_ORIGIN || '*';
const RATE_WINDOW_MS = Number(process.env.AURA_RATE_WINDOW_MS || 60_000);
const RATE_MAX = Number(process.env.AURA_RATE_MAX || 60);
const rateMap = new Map();
const MODEL_URL = process.env.AURA_MODEL_URL || '';
const MODEL_KEY = process.env.AURA_MODEL_KEY || '';
const MODEL_NAME = process.env.AURA_MODEL_NAME || 'online-model';
const MAX_BODY = 1_000_000;
const KNOWLEDGE_DIR = path.join(DATA, 'knowledge');
const BUILD_VERSION = '9.0.0-RealityStudio';
const MODEL_TIMEOUT_MS = Number(process.env.AURA_MODEL_TIMEOUT_MS || 20000);
const MAX_MODELS = 8;

await fs.mkdir(DATA, {recursive:true});
await fs.mkdir(KNOWLEDGE_DIR, {recursive:true});
for (const [name, initial] of [['memory.json', []], ['conversations.json', []]]) {
  try { await fs.access(path.join(DATA,name)); } catch { await fs.writeFile(path.join(DATA,name), JSON.stringify(initial,null,2)); }
}

const json = (res, code, data, extra={}) => { res.writeHead(code, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-aura-request-id':extra.requestId||''}); res.end(JSON.stringify(data)); };
const security = res => { res.setHeader('x-content-type-options','nosniff'); res.setHeader('x-frame-options','SAMEORIGIN'); res.setHeader('referrer-policy','no-referrer'); res.setHeader('permissions-policy','camera=(), microphone=(), geolocation=()'); };
const cors = res => { res.setHeader('access-control-allow-origin', CORS_ORIGIN); res.setHeader('access-control-allow-methods','GET,POST,DELETE,OPTIONS'); res.setHeader('access-control-allow-headers','content-type,authorization,x-aura-client'); res.setHeader('access-control-max-age','86400'); };
function allowRequest(ip){ const now=Date.now(); const row=rateMap.get(ip)||{start:now,count:0}; if(now-row.start>RATE_WINDOW_MS){row.start=now;row.count=0;} row.count++; rateMap.set(ip,row); if(rateMap.size>5000) for(const [k,v] of rateMap) if(now-v.start>RATE_WINDOW_MS) rateMap.delete(k); return row.count<=RATE_MAX; }
const text = (res, code, body, type='text/plain; charset=utf-8') => { security(res); res.writeHead(code, {'content-type':type}); res.end(body); };
const readJson = async file => JSON.parse(await fs.readFile(file,'utf8'));
const writeJson = async (file, value) => { const tmp=file+'.tmp'; await fs.writeFile(tmp,JSON.stringify(value,null,2)); await fs.rename(tmp,file); };
const body = req => new Promise((resolve,reject)=>{ let s=''; req.on('data',c=>{s+=c;if(s.length>MAX_BODY){req.destroy();reject(new Error('body too large'));}}); req.on('end',()=>{try{resolve(JSON.parse(s||'{}'));}catch(e){reject(e);}}); req.on('error',reject); });

function safePath(urlPath){
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  const rel = decoded === '/' ? '/index.html' : decoded;
  const full = path.resolve(WWW, '.'+rel);
  if (!full.startsWith(WWW+path.sep) && full!==WWW) return null;
  return full;
}

function extractModelText(data){
  if (typeof data?.output_text === 'string') return data.output_text;
  if (typeof data?.response === 'string') return data.response;
  if (typeof data?.message === 'string') return data.message;
  if (Array.isArray(data?.choices)) return data.choices.map(c => c?.message?.content ?? c?.text ?? '').join('\n').trim();
  if (Array.isArray(data?.output)) return data.output.flatMap(x=>x?.content||[]).map(x=>x?.text||'').join('\n').trim();
  return '';
}

function configuredModels(){
  let rows=[];
  try { rows=JSON.parse(process.env.AURA_MODELS || '[]'); } catch {}
  if(!Array.isArray(rows)) rows=[];
  if(MODEL_URL) rows.unshift({name:MODEL_NAME,url:MODEL_URL,key:MODEL_KEY,weight:1});
  const seen=new Set();
  return rows.filter(x=>x && x.url && !seen.has(x.url) && seen.add(x.url)).slice(0,MAX_MODELS).map((x,i)=>({name:String(x.name||`model-${i+1}`),url:String(x.url),key:String(x.key||''),weight:Number(x.weight||1)}));
}
async function callModel(model,messages,temperature=0.2){
  const headers={'content-type':'application/json','x-aura-client':'omnimind'};
  if(model.key) headers.authorization=`Bearer ${model.key}`;
  const payload={model:model.name,messages,temperature};
  const ac=new AbortController(); const timer=setTimeout(()=>ac.abort(),MODEL_TIMEOUT_MS);
  try {
    const r=await fetch(model.url,{method:'POST',headers,body:JSON.stringify(payload),signal:ac.signal});
    const raw=await r.text(); let data; try{data=JSON.parse(raw);}catch{data={raw};}
    if(!r.ok) throw new Error(`Model HTTP ${r.status}: ${typeof data?.error==='string'?data.error:raw.slice(0,500)}`);
    const out=extractModelText(data); if(!out) throw new Error('Model returned no text');
    return {ok:true,text:out,model:model.name};
  } finally { clearTimeout(timer); }
}
async function onlineModel(messages){
  const models=configuredModels(); if(!models.length) return {ok:false,reason:'MODEL_NOT_CONFIGURED',models:[]};
  const errors=[];
  for(const model of models){ try { return await callModel(model,messages); } catch(e){ errors.push({model:model.name,error:e.message}); } }
  return {ok:false,reason:'ALL_MODELS_FAILED',errors};
}
function modelRoute(task){
  const t=String(task||'general').toLowerCase();
  if(/code|debug|architect|api|security|backend|frontend|android|ios|database|devops/.test(t)) return 'engineering';
  if(/design|graphic|ui|ux|visual|image|motion|brand/.test(t)) return 'visual';
  if(/social|content|marketing|caption|reel|tiktok|instagram/.test(t)) return 'social';
  if(/research|compare|analy|document/.test(t)) return 'research';
  return 'general';
}
async function ensembleModel(messages,{critique=true}={}){
  const models=configuredModels(); if(!models.length) return {ok:false,reason:'MODEL_NOT_CONFIGURED',mode:'no-model'};
  const outputs=[];
  for(const model of models.slice(0,4)){ try { outputs.push(await callModel(model,messages,0.2)); } catch(e){} }
  if(!outputs.length) return {ok:false,reason:'ALL_MODELS_FAILED',mode:'ensemble'};
  if(outputs.length===1 || !critique) return {ok:true,text:outputs[0].text,mode:'ensemble-single',models:outputs.map(x=>x.model)};
  const synthesis=[...messages,{role:'user',content:`SYNTHESIS TASK. Compare these independent candidate answers. Preserve correct facts, remove unsupported claims, resolve contradictions explicitly, and produce one actionable answer.

${outputs.map((x,i)=>`CANDIDATE ${i+1} (${x.model}):\n${x.text}`).join('\n\n')}`}];
  try { const judge=await callModel(models[0],synthesis,0.1); return {ok:true,text:judge.text,mode:'ensemble-consensus',models:outputs.map(x=>x.model),candidates:outputs.length}; } catch { return {ok:true,text:outputs[0].text,mode:'ensemble-fallback',models:outputs.map(x=>x.model),candidates:outputs.length}; }
}

function stripTags(s){return s.replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&#x27;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();}
async function webSearch(q){
  const u='https://html.duckduckgo.com/html/?q='+encodeURIComponent(q);
  const r=await fetch(u,{headers:{'user-agent':'Aura-Online-Brain/2.0'}});
  if(!r.ok) throw new Error(`Search HTTP ${r.status}`);
  const html=await r.text();
  const out=[]; const re=/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m; while((m=re.exec(html)) && out.length<8){ out.push({title:stripTags(m[2]),url:m[1]}); }
  return out;
}

const SYSTEM=`You are Aura Online Brain, a practical autonomous assistant for the user's Aura SocialOps workspace. You have a million-domain deterministic engineering atlas spanning software, systems, data, AI, security, cloud, embedded, graphics, product, and accessibility disciplines. When relevant, use their rules and verification practices. Never claim a visual or code result was tested unless a test actually ran. \nRules: be factual, concise, and transparent about uncertainty. Never fabricate live data, prices, links, analytics, actions, or tool results. Use supplied memory and web results as context, not as unquestionable truth. If a tool is unavailable, say so. Prefer actionable steps. The user remains in control of external actions.`;

function clampText(v,max=12000){ return String(v??'').slice(0,max); }
function tokenize(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9\s#@._-]/g,' ').split(/\s+/).filter(Boolean); }
function overlap(a,b){ const A=new Set(tokenize(a)), B=new Set(tokenize(b)); if(!A.size||!B.size) return 0; let n=0; for(const x of A) if(B.has(x)) n++; return n/Math.max(1,Math.min(A.size,B.size)); }
function smartSignals(memories){
  const texts=memories.map(x=>x.text||'');
  const joined=texts.join('\n');
  const asks=texts.filter(t=>/[?]$|\b(how|what|which|link|price|buy|where|can you)\b/i.test(t));
  const metrics=texts.filter(t=>/\b(views?|saves?|shares?|comments?|clicks?|retention|watch time|impressions?|conversion|ctr)\b/i.test(t));
  const repeated=[];
  for(let i=0;i<texts.length;i++) for(let j=i+1;j<texts.length;j++) if(overlap(texts[i],texts[j])>=0.72) repeated.push([texts[i],texts[j]]);
  return {memoryCount:texts.length,audienceQuestions:asks.slice(0,8),metricNotes:metrics.slice(0,8),repeatedThemes:repeated.slice(0,5),recentMemory:texts.slice(0,10),tokenHints:[...new Set(tokenize(joined))].slice(0,40)};
}

async function saveConversation(record){
  const file=path.join(DATA,'conversations.json'); const items=await readJson(file); items.unshift(record); await writeJson(file,items.slice(0,500));
}


async function engineeringKnowledge(){
  try { return await readJson(path.join(KNOWLEDGE_DIR, 'engineering.json')); } catch { return []; }
}
async function knowledgePack(domain){
  const safe = domain==='coding' || domain==='graphics' ? domain : null;
  if(!safe) return [];
  try { return await readJson(path.join(KNOWLEDGE_DIR, `${safe}.json`)); } catch { return []; }
}
function rankKnowledge(items,q){
  const terms=new Set(tokenize(q));
  return items.map(x=>{const hay=tokenize(`${x.topic} ${x.rule} ${(x.tags||[]).join(' ')}`); let score=0; for(const t of terms) if(hay.includes(t)) score++; return {...x,score};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,12);
}
function rankEngineering(items,q){
  const terms=new Set(tokenize(q));
  return items.map(x=>{const hay=tokenize(`${x.domain} ${x.topic} ${x.rule} ${x.failure_mode} ${x.verification} ${(x.tags||[]).join(' ')}`); let score=0; for(const t of terms) if(hay.includes(t)) score++; return {...x,score};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,25);
}
function engineeringReview(input){
  const src=clampText(input,80000); const checks=[]; const push=(id,ok,detail)=>checks.push({id,ok,detail});
  push('requirements',/requirement|acceptance|goal/i.test(src),'Requirements or acceptance criteria should be explicit.');
  push('validation',/validate|schema|sanitize|constraint/i.test(src),'Input and state validation should be visible.');
  push('error-handling',/catch|error|fallback|retry/i.test(src),'Failure paths should be explicit and actionable.');
  push('security',/auth|token|secret|https|permission/i.test(src),'Security controls should be considered for trust boundaries.');
  push('observability',/log|metric|trace|request.?id|telemetry/i.test(src),'Important production behavior should be observable.');
  push('testing',/test|assert|check|selftest|smoke/i.test(src),'Changed behavior should have executable verification.');
  push('performance',/cache|timeout|abort|batch|lazy|profile|latency/i.test(src),'Performance-sensitive paths should have explicit controls.');
  push('accessibility',/aria|alt=|focus|keyboard|contrast|reduced-motion/i.test(src),'User-facing UI should expose accessibility considerations.');
  push('deployment',/docker|railway|render|netlify|vercel|ci|github actions|gradle/i.test(src),'Deployment/release behavior should be reproducible.');
  const score=Math.round(checks.filter(x=>x.ok).length/checks.length*100);
  return {score,checks,principle:'A score is a coverage signal, not proof of correctness. Run the project-specific tests before release.'};
}
function codingReview(input){
  const src=clampText(input,50000); const findings=[];
  if(/(api[_-]?key|secret|token)\s*[:=]\s*['"][^'"]+/i.test(src)) findings.push(['critical','possible hard-coded secret','Move credentials to server-side environment variables.']);
  if(/fetch\([^)]*http:\/\//i.test(src)) findings.push(['high','insecure HTTP endpoint','Use HTTPS for remote production endpoints.']);
  if(/innerHTML\s*=/i.test(src)) findings.push(['medium','HTML injection surface','Sanitize untrusted content or prefer textContent/DOM APIs.']);
  if(/catch\s*\{\s*\}/i.test(src)) findings.push(['medium','swallowed error','Surface an actionable error or record diagnostics.']);
  if(/setTimeout\([^,]+,\s*0\)/i.test(src)) findings.push(['low','deferred work','Confirm this scheduling is intentional and does not hide race conditions.']);
  if(!/AbortSignal|timeout/i.test(src) && /fetch\(/i.test(src)) findings.push(['medium','network timeout missing','Use an AbortController/timeout for network calls.']);
  if(!/test|assert|check/i.test(src)) findings.push(['low','verification not visible','Add an executable test or self-check for the changed behavior.']);
  return {domain:'coding',findings,checks:{inputBytes:Buffer.byteLength(src),networkTimeout: /AbortSignal|timeout/i.test(src),secretScan:!findings.some(x=>x[1].includes('secret'))}};
}
function visualReview(html){
  const src=clampText(html,80000); const findings=[];
  const checks={viewport:/<meta[^>]+name=["']viewport/i.test(src),manifest:/manifest\.json/i.test(src),serviceWorker:/serviceWorker|sw\.js/i.test(src),responsive:/@media|clamp\(|min\(|max\(/i.test(src),focus:/focus-visible|:focus/i.test(src),reducedMotion:/prefers-reduced-motion/i.test(src),altText:/\balt\s*=/i.test(src),touchTargets:/44px|48px|padding:\s*(?:1[2-9]|[2-9]\d)px/i.test(src)};
  if(!checks.viewport) findings.push(['high','viewport metadata missing','Add a mobile viewport meta tag.']);
  if(!checks.manifest) findings.push(['medium','PWA manifest reference missing','Link manifest.json when this is a PWA.']);
  if(!checks.serviceWorker) findings.push(['medium','service-worker integration not detected','Register the service worker for offline behavior when intended.']);
  if(!checks.responsive) findings.push(['medium','responsive layout signals weak','Add fluid constraints or media/container queries.']);
  if(!checks.focus) findings.push(['medium','keyboard focus styling not detected','Add visible :focus-visible states.']);
  if(!checks.reducedMotion) findings.push(['low','reduced-motion handling not detected','Respect prefers-reduced-motion for nonessential animation.']);
  if(/<img\b/i.test(src) && !checks.altText) findings.push(['high','image alt text not detected','Provide useful alt text or explicit decorative semantics.']);
  return {domain:'graphics',findings,checks,htmlBytes:Buffer.byteLength(src)};
}

async function handle(req,res){
  const requestId=crypto.randomUUID();
  cors(res);
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end();}
  const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
  if(!allowRequest(ip)) return json(res,429,{ok:false,error:'RATE_LIMITED',requestId},{requestId});
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try{
    if(req.method==='GET' && u.pathname==='/api/knowledge/status') {
      const kb=await engineeringKnowledge(); const domainSet=[...new Set(kb.map(x=>x.domain))].sort();
      return json(res,200,{ok:true,version:BUILD_VERSION,domainCount:domainSet.length,ruleCount:kb.length,total:kb.length,domains:{coding:Math.floor(domainSet.length/2),graphics:domainSet.length-Math.floor(domainSet.length/2)},coverage:domainSet.map(d=>({domain:d,count:kb.filter(x=>x.domain===d).length})),generatedAt:new Date().toISOString(),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/knowledge/search') {
      const q=clampText(u.searchParams.get('q')||'',500); const kb=await engineeringKnowledge();
      const results=rankEngineering(kb,q); return json(res,200,{ok:true,q,results,requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/brain/coding-review') { const b=await body(req); return json(res,200,{ok:true,...codingReview(b.code||b.text||''),generatedAt:new Date().toISOString(),requestId}); }
    if(req.method==='POST' && u.pathname==='/api/brain/visual-review') { const b=await body(req); return json(res,200,{ok:true,...visualReview(b.html||b.text||''),generatedAt:new Date().toISOString(),requestId}); }
    if(req.method==='GET' && u.pathname==='/api/model/status') {
      const models=configuredModels();
      return json(res,200,{ok:true,version:BUILD_VERSION,router:'OmniMind',models:models.map(m=>({name:m.name,urlConfigured:Boolean(m.url),keyConfigured:Boolean(m.key)})),count:models.length,timeoutMs:MODEL_TIMEOUT_MS,strategies:['fallback','task-routing','ensemble-consensus'],requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/model/route') {
      const b=await body(req); const task=String(b.task||b.prompt||'').trim(); if(!task) return json(res,400,{ok:false,error:'task required',requestId});
      const route=modelRoute(task); const messages=[{role:'system',content:SYSTEM+`\nYou are the ${route} specialist in a multi-agent system. Be evidence-driven and state uncertainty.`},{role:'user',content:task}];
      const result=await ensembleModel(messages,{critique:b.critique!==false});
      return json(res,result.ok?200:503,{ok:result.ok,route,...result,requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/model/ensemble') {
      const b=await body(req); const prompt=String(b.prompt||'').trim(); if(!prompt) return json(res,400,{ok:false,error:'prompt required',requestId});
      const result=await ensembleModel([{role:'system',content:SYSTEM+`\nUse disciplined reasoning, separate facts from assumptions, and do not claim tests you did not run.`},{role:'user',content:prompt}],{critique:b.critique!==false});
      return json(res,result.ok?200:503,{ok:result.ok,...result,requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/engineering/status'){
      const kb=await engineeringKnowledge();
      const domains=[...new Set(kb.map(x=>x.domain))].sort();
      return json(res,200,{ok:true,version:BUILD_VERSION,atlasVersion:ATLAS_VERSION,domainCount:ATLAS_DOMAIN_COUNT,ruleCount:ATLAS_DOMAIN_COUNT*RULES_PER_DOMAIN,count:kb.length,domains:domains.slice(0,100),coverage:domains.slice(0,100).map(d=>({domain:d,count:kb.filter(x=>x.domain===d).length})),materializedRuleCount:kb.length,materializedDomainCount:domains.length,rulesPerDomain:RULES_PER_DOMAIN,taxonomy:{families:ATLAS_TAXONOMY.families.length,specializations:ATLAS_TAXONOMY.specs.length,contexts:ATLAS_TAXONOMY.contexts.length,environments:ATLAS_TAXONOMY.environments.length,lifecycles:ATLAS_TAXONOMY.lifecycles.length},principles:['inspect','design','implement','test','secure','observe','release','learn','measure','learn'],requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/engineering/domain'){
      const id=u.searchParams.get('id'); const index=u.searchParams.get('index');
      const d=id?domainById(id):domainAt(Number(index));
      if(!d) return json(res,404,{ok:false,error:'domain not found',requestId});
      return json(res,200,{ok:true,domain:d,rules:rulesForDomain(d),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/engineering/domains'){
      const q=String(u.searchParams.get('q')||'').trim(); const limit=Math.min(100,Math.max(1,Number(u.searchParams.get('limit')||25)));
      if(!q) return json(res,200,{ok:true,query:'',results:randomSample(Math.min(limit,20)),requestId});
      return json(res,200,{ok:true,query:q,results:findDomains(q,limit),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/engineering/rules'){
      const id=u.searchParams.get('domainId'); const d=domainById(id); if(!d) return json(res,404,{ok:false,error:'domainId required or not found',requestId});
      return json(res,200,{ok:true,domain:d,rules:rulesForDomain(d),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/engineering/search'){
      const q=String(u.searchParams.get('q')||'').trim();
      if(!q) return json(res,400,{ok:false,error:'q required',requestId});
      const atlas=findDomains(q,20); const materialized=rankEngineering(await engineeringKnowledge(),q).slice(0,10);
      return json(res,200,{ok:true,query:q,atlasResults:atlas,materializedResults:materialized,results:[...atlas,...materialized].slice(0,25),requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/engineering/review'){
      const b=await body(req); const source=String(b.source||b.code||b.text||'');
      if(!source.trim()) return json(res,400,{ok:false,error:'source required',requestId});
      const review=engineeringReview(source); const coding=codingReview(source); const visual=visualReview(source);
      return json(res,200,{ok:true,review,coding,visual,requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/engineering/plan'){
      const b=await body(req); const goal=String(b.goal||'').trim(); const context=String(b.context||'');
      if(!goal) return json(res,400,{ok:false,error:'goal required',requestId});
      const kb=await engineeringKnowledge(); const matches=rankEngineering(kb,goal+' '+context).slice(0,12);
      const plan=[['Discover','define requirements, constraints, users, inputs and outputs'],['Architect','map boundaries, dependencies, data flow and failure modes'],['Implement','make the smallest reversible change with secure defaults'],['Verify','run syntax, unit/integration/smoke and visual checks that actually apply'],['Harden','validate inputs, protect secrets, add timeouts, accessibility and observability'],['Release','create a reproducible artifact, record version/hash and rollback path'],['Learn','capture real results, defects and decisions as durable memory']];
      return json(res,200,{ok:true,goal,stages:plan.map(([stage,action])=>({stage,action})),relevantKnowledge:matches,requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/system/overview'){
      const models=configuredModels();
      const memory=await readJson(path.join(DATA,'memory.json'));
      const conversations=await readJson(path.join(DATA,'conversations.json'));
      const checks={
        runtime:{ok:Number(process.versions.node.split('.')[0])>=18,node:process.version,host:HOST,port:PORT},
        storage:{ok:true,memoryCount:memory.length,conversationCount:conversations.length,dataDir:DATA},
        modelFabric:{ok:true,configured:models.length>0,count:models.length,max:MAX_MODELS,timeoutMs:MODEL_TIMEOUT_MS},
        protection:{ok:true,rateLimit:`${RATE_MAX}/${RATE_WINDOW_MS}ms`,maxBody:MAX_BODY,cors:CORS_ORIGIN},
        surfaces:{ok:true,pages:['vision','operator','omnimind','engineering','mission','showcase']}
      };
      return json(res,200,{ok:true,version:BUILD_VERSION,overall:'operational',checks,capabilities:['evidence-first','deterministic-fallback','multi-model-routing','ensemble-consensus','persistent-memory','backup-import-export','responsive-ui'],generatedAt:new Date().toISOString(),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/vision/status'){
      const memories=await readJson(path.join(DATA,'memory.json')); const conversations=await readJson(path.join(DATA,'conversations.json')); const models=configuredModels();
      return json(res,200,{ok:true,version:BUILD_VERSION,vision:'100X-ProMax',layers:['command','navigation','responsive','accessibility','motion','theme','system-state','evidence-first'],pages:['vision','operator','omnimind','engineering','mission','showcase'],memoryCount:memories.length,conversationCount:conversations.length,modelCount:models.length,online:true,time:new Date().toISOString(),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/health') return json(res,200,{ok:true,online:true,version:BUILD_VERSION,modelConfigured:configuredModels().length>0,modelCount:configuredModels().length,searchAvailable:true,host:HOST,time:new Date().toISOString(),requestId});
    if(req.method==='GET' && u.pathname==='/api/brain/status'){
      const memories=await readJson(path.join(DATA,'memory.json')); const conversations=await readJson(path.join(DATA,'conversations.json'));
      return json(res,200,{ok:true,version:BUILD_VERSION,online:true,model:{configured:Boolean(MODEL_URL),name:MODEL_NAME,urlConfigured:Boolean(MODEL_URL)},searchAvailable:true,memoryCount:memories.length,conversationCount:conversations.length,signals:smartSignals(memories),time:new Date().toISOString()});
    }
    if(req.method==='GET' && u.pathname==='/api/brain/insights'){
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,100);
      const signals=smartSignals(memories);
      return json(res,200,{ok:true,generatedAt:new Date().toISOString(),insights:[
        signals.audienceQuestions.length?`Audience questions detected: ${signals.audienceQuestions.length}`:'No audience-question evidence stored yet.',
        signals.metricNotes.length?`Metric evidence detected in ${signals.metricNotes.length} memory items.`:'No metric evidence stored yet.',
        signals.repeatedThemes.length?`Repeated themes detected: ${signals.repeatedThemes.length}`:'No repeated themes detected.'
      ],signals});
    }
    if(req.method==='GET' && u.pathname==='/api/diagnostics'){
      const memories=await readJson(path.join(DATA,'memory.json')); const conversations=await readJson(path.join(DATA,'conversations.json'));
      return json(res,200,{ok:true,version:BUILD_VERSION,node:process.version,uptime:process.uptime(),modelConfigured:Boolean(MODEL_URL),searchAvailable:true,memoryCount:memories.length,conversationCount:conversations.length,dataWritable:true,api:['/api/health','/api/vision/status','/api/system/overview','/api/brain/status','/api/brain/insights','/api/brain/recommendation','/api/memory','/api/social-plan','/api/adaptive-cycle','/api/cycle','/api/social-cycle','/api/experiment/log','/api/search','/api/chat','/api/backup/export','/api/backup/import','/api/knowledge/status','/api/knowledge/search','/api/brain/coding-review','/api/brain/visual-review','/api/engineering/status','/api/engineering/search','/api/engineering/review','/api/engineering/plan','/api/model/status','/api/model/route','/api/model/ensemble'],generatedAt:new Date().toISOString(),requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/backup/export'){
      const memory=await readJson(path.join(DATA,'memory.json')); const conversations=await readJson(path.join(DATA,'conversations.json'));
      return json(res,200,{schema:'aura-backup-v1',version:BUILD_VERSION,exportedAt:new Date().toISOString(),memory,conversations,requestId});
    }
    if(req.method==='POST' && u.pathname==='/api/backup/import'){
      const b=await body(req); if(b.schema!=='aura-backup-v1'||!Array.isArray(b.memory)||!Array.isArray(b.conversations)) return json(res,400,{ok:false,error:'INVALID_BACKUP',requestId});
      await writeJson(path.join(DATA,'memory.json'),b.memory.slice(0,1000)); await writeJson(path.join(DATA,'conversations.json'),b.conversations.slice(0,500));
      return json(res,200,{ok:true,memoryCount:b.memory.length,conversationCount:b.conversations.length,requestId});
    }
    if(req.method==='GET' && u.pathname==='/api/memory') return json(res,200,{items:await readJson(path.join(DATA,'memory.json'))});
    if(req.method==='POST' && u.pathname==='/api/memory'){
      const b=await body(req); const text=String(b.text||'').trim(); if(!text) return json(res,400,{error:'text required'});
      const items=await readJson(path.join(DATA,'memory.json')); const item={id:crypto.randomUUID(),text,createdAt:new Date().toISOString(),source:String(b.source||'user').slice(0,80),tags:Array.isArray(b.tags)?b.tags.slice(0,20).map(x=>String(x).slice(0,60)):[]}; items.unshift(item); await writeJson(path.join(DATA,'memory.json'),items.slice(0,1000)); return json(res,201,item);
    }
    if(req.method==='DELETE' && u.pathname.startsWith('/api/memory/')){
      const id=u.pathname.split('/').pop(); const items=await readJson(path.join(DATA,'memory.json')); await writeJson(path.join(DATA,'memory.json'),items.filter(x=>x.id!==id)); return json(res,200,{ok:true});
    }
    if(req.method==='POST' && u.pathname==='/api/social-plan'){
      const b=await body(req); const platforms=String(b.platforms||'x,ig,tiktok').trim(); const niche=String(b.niche||'').trim(); const goal=String(b.goal||'').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,100); const signals=smartSignals(memories);
      const platformList=platforms.split(',').map(x=>x.trim()).filter(Boolean).slice(0,5);
      const plan={mode:'deterministic-planner',platforms:platformList,niche,goal,principles:['one audience problem per post','one CTA per post','use evidence before changing strategy','do not fabricate metrics or product facts'],sequence:[
        {step:1,action:'Collect evidence',check:signals.metricNotes.length?'Use stored metric notes.':'Record views, retention/watch time, saves, shares, comments and clicks after publishing.'},
        {step:2,action:'Choose the next hypothesis',check:signals.audienceQuestions.length?'Start from the strongest audience question.':'Use one clear pain point from the niche; do not invent audience demand.'},
        {step:3,action:'Publish one controlled test',check:'Change one major variable only: hook, pacing, format, or CTA.'},
        {step:4,action:'Measure at 24h and 7d',check:'Compare against the creator’s own prior evidence, not promises or universal benchmarks.'},
        {step:5,action:'Update memory',check:'Save the result and what changed so Aura can learn from the next cycle.'}
      ],signals};
      return json(res,200,{ok:true,plan,generatedAt:new Date().toISOString()});
    }
    if(req.method==='GET' && u.pathname==='/api/brain/recommendation'){
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,100);
      const signals=smartSignals(memories);
      const conversations=(await readJson(path.join(DATA,'conversations.json'))).slice(0,100);
      const cycles=conversations.filter(x=>x.type==='social-cycle'||x.type==='adaptive-cycle');
      let action='Collect the first real performance observation before changing strategy.';
      let reason='No metric evidence is stored yet.';
      if(signals.audienceQuestions.length){ action='Build the next experiment around the strongest real audience question.'; reason=`${signals.audienceQuestions.length} audience-question signal(s) found in memory.`; }
      else if(signals.metricNotes.length){ action='Compare the latest metric evidence with the previous observation and change one variable only.'; reason=`${signals.metricNotes.length} metric-bearing memory item(s) found.`; }
      else if(cycles.length){ action='Review the latest generated cycle, publish one controlled test, then record its real result.'; reason=`${cycles.length} prior cycle record(s) exist, but no structured performance evidence is stored.`; }
      return json(res,200,{ok:true,action,reason,confidence:signals.audienceQuestions.length||signals.metricNotes.length?'evidence-backed':'insufficient-evidence',signals,cycles:cycles.length,generatedAt:new Date().toISOString()});
    }
    if(req.method==='POST' && u.pathname==='/api/experiment/log'){
      const b=await body(req);
      const observation=String(b.observation||'').trim();
      if(!observation) return json(res,400,{error:'observation required'});
      const item={id:crypto.randomUUID(),text:observation,createdAt:new Date().toISOString(),source:'experiment-log',tags:['experiment',String(b.platform||'').slice(0,40),String(b.variable||'').slice(0,40)].filter(Boolean)};
      const items=await readJson(path.join(DATA,'memory.json')); items.unshift(item); await writeJson(path.join(DATA,'memory.json'),items.slice(0,1000));
      return json(res,201,{ok:true,item});
    }
    if(req.method==='POST' && (u.pathname==='/api/adaptive-cycle' || u.pathname==='/api/cycle')){
      const b=await body(req);
      const platforms=String(b.platforms||'x,ig,tiktok').trim();
      const niche=String(b.niche||'').trim(); const goal=String(b.goal||'').trim(); const tone=String(b.tone||'Direct').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,120); const signals=smartSignals(memories);
      const [codingKB,graphicsKB]=await Promise.all([knowledgePack('coding'),knowledgePack('graphics')]);
      const engineeringContext={coding:codingKB.slice(0,8),graphics:graphicsKB.slice(0,8)};
      const platformList=platforms.split(',').map(x=>x.trim()).filter(Boolean).slice(0,5);
      const evidence=signals.audienceQuestions[0]||signals.metricNotes[0]||'';
      const experiment={hypothesis:evidence?`Use the strongest stored signal as the next content hypothesis.`:`No demand signal is stored; test one clearly stated audience pain point without claiming proof.`,variable:'hook',control:'Keep platform, offer, format and core topic stable.',measure:['views/impressions','retention or average watch','saves/shares','comments/replies','profile/link clicks'],decision:'Keep the winning variable only after comparable observations; otherwise run another controlled test.'};
      const deterministic=`AURA · ADAPTIVE SOCIAL CYCLE\nNiche: ${niche}\nGoal: ${goal}\nPlatforms: ${platformList.join(', ')}\nTone: ${tone}\n\nEVIDENCE STATUS\n${evidence?'Real stored evidence found: '+evidence.slice(0,700):'Insufficient evidence: Aura will not invent audience demand, metrics, products, prices, links, or results.'}\n\nNEXT CONTROLLED EXPERIMENT\nHypothesis: ${experiment.hypothesis}\nVariable: ${experiment.variable}\nControl: ${experiment.control}\nMeasure: ${experiment.measure.join(' | ')}\nDecision rule: ${experiment.decision}\n\nCONTENT OUTPUT\n1. Hook: Show the result/problem in the first 1–1.5 seconds.\n2. Body: One concrete lesson for ${niche}; use only facts you can verify.\n3. CTA: One next action tied to ${goal}.\n4. Repurpose: Adapt the same core idea to each selected platform rather than creating unrelated posts.\n5. Learning: After publishing, log the actual numbers and audience comments back into Aura.\n\nAURA RULE: one major variable per experiment; missing data stays missing.`;
      try{
        const prompt=[{role:'system',content:SYSTEM+`\nYou are running an adaptive social experiment. Use the supplied evidence. Never invent performance, audience demand, products, prices, links, or claims. Return: hypothesis, 5 platform-aware post drafts, 3 genuine reply templates, lead magnet, monetization step, 5 metrics, stop condition, and next experiment. One major variable only.`},{role:'user',content:`Platforms: ${platformList.join(', ')}\nNiche: ${niche}\nGoal: ${goal}\nTone: ${tone}\nStored signals: ${JSON.stringify(signals)}\nEngineering memory: ${JSON.stringify(engineeringContext)}\nGenerate one controlled cycle.` }];
        const m=await onlineModel(prompt);
        if(m.ok){ const generatedAt=new Date().toISOString(); await saveConversation({id:crypto.randomUUID(),type:'adaptive-cycle',platforms,niche,goal,tone,text:m.text,signals,createdAt:generatedAt}); return json(res,200,{ok:true,mode:'online-model',text:m.text,signals,experiment,generatedAt}); }
      }catch(e){ return json(res,502,{ok:false,mode:'model-error',error:e.message,signals,experiment}); }
      const generatedAt=new Date().toISOString(); await saveConversation({id:crypto.randomUUID(),type:'adaptive-cycle',platforms,niche,goal,tone,text:deterministic,signals,createdAt:generatedAt});
      return json(res,200,{ok:true,mode:'deterministic-evidence-engine',text:deterministic,signals,experiment,generatedAt});
    }
    if(req.method==='POST' && u.pathname==='/api/cycle'){
      const b=await body(req);
      const platforms=String(b.platforms||'x,ig,tiktok').trim();
      const niche=String(b.niche||'').trim();
      const goal=String(b.goal||'').trim();
      const tone=String(b.tone||'Direct · zero hype · numbers over adjectives').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,120);
      const signals=smartSignals(memories);
      const [codingKB,graphicsKB]=await Promise.all([knowledgePack('coding'),knowledgePack('graphics')]);
      const engineeringContext={coding:codingKB.slice(0,8),graphics:graphicsKB.slice(0,8)};
      const platformList=platforms.split(',').map(x=>x.trim()).filter(Boolean).slice(0,5);
      const evidence=signals.audienceQuestions[0]||signals.metricNotes[0]||'';
      const experiment={hypothesis:evidence?'Use the strongest stored signal as the next content hypothesis.':'No demand signal is stored; test one clearly stated audience pain point without claiming proof.',variable:'hook',control:'Keep platform, offer, format and core topic stable.',measure:['views/impressions','retention or average watch','saves/shares','comments/replies','profile/link clicks'],decision:'Keep the winning variable only after comparable observations; otherwise run another controlled test.'};
      const fallback=`AURA · SOCIAL CYCLE\nNiche: ${niche}\nGoal: ${goal}\nPlatforms: ${platformList.join(', ')}\nTone: ${tone}\n\nEVIDENCE STATUS\n${evidence?'Real stored evidence found: '+evidence.slice(0,700):'Insufficient evidence: Aura will not invent audience demand, metrics, products, prices, links, or results.'}\n\nNEXT CONTROLLED EXPERIMENT\nHypothesis: ${experiment.hypothesis}\nVariable: ${experiment.variable}\nControl: ${experiment.control}\nMeasure: ${experiment.measure.join(' | ')}\nDecision rule: ${experiment.decision}\n\n5 POST DRAFTS\n1. Hook: Show the result/problem in the first 1–1.5 seconds.\n   Body: One concrete lesson for ${niche}; verify every factual claim.\n   CTA: One next action tied to ${goal}.\n2. Adapt the same core idea for ${platformList[1]||platformList[0]}; keep one variable changed.\n3. Create a short-form version for ${platformList[2]||platformList[0]}; no invented proof.\n4. Turn the strongest audience question into a practical answer.\n5. Repurpose the same evidence-backed idea into a concise follow-up.\n\n3 REPLY TEMPLATES\n• Add one specific observation from the post, then ask one useful question.\n• Offer a clearly labeled counterpoint based on your own experience.\n• Share a relevant resource only when it genuinely answers the question.\n\nLEAD MAGNET\nA one-page checklist directly tied to ${goal}.\n\nMONETIZATION\nPublish the useful free asset first, then connect the paid offer only where it solves the stated problem.\n\n5 METRICS\nViews/impressions · retention/watch time · saves/shares · comments/replies · profile/link clicks\n\nSTOP\nStop changing multiple variables after one weak result.\n\nLEARNING\nLog the actual result after publishing so Aura can compare the next observation.`;
      try{
        const prompt=[
          {role:'system',content:SYSTEM+`\nYou are Aura's real social operator. Use supplied evidence and memory. Never invent performance, audience demand, products, prices, links, testimonials, or results. Return exactly: 5 platform-aware post drafts with hook/body/CTA/time, 3 genuine reply templates, 1 lead magnet, 1 monetization step, 5 metrics, 1 thing to stop, and the next controlled experiment. Change one major variable only.`},
          {role:'user',content:`Platforms: ${platformList.join(', ')}\nNiche: ${niche}\nGoal: ${goal}\nTone: ${tone}\nStored evidence: ${JSON.stringify(signals)}\nEngineering memory: ${JSON.stringify(engineeringContext)}\nRun one full Aura social cycle.`}
        ];
        const m=await onlineModel(prompt);
        if(m.ok){ const generatedAt=new Date().toISOString(); await saveConversation({id:crypto.randomUUID(),type:'cycle',platforms,niche,goal,tone,text:m.text,signals,createdAt:generatedAt}); return json(res,200,{ok:true,mode:'online-model',text:m.text,signals,experiment,generatedAt}); }
      }catch(e){ return json(res,502,{ok:false,mode:'model-error',error:e.message,signals,experiment}); }
      const generatedAt=new Date().toISOString();
      await saveConversation({id:crypto.randomUUID(),type:'cycle',platforms,niche,goal,tone,text:fallback,signals,createdAt:generatedAt});
      return json(res,200,{ok:true,mode:'deterministic-evidence-engine',text:fallback,signals,experiment,generatedAt});
    }
    if(req.method==='POST' && u.pathname==='/api/social-cycle'){
      const b=await body(req);
      const platforms=String(b.platforms||'x,ig,tiktok').trim();
      const niche=String(b.niche||'ai tools for solo founders').trim();
      const goal=String(b.goal||'email list + $29/mo product').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const prompt=`Run one full social cycle. Platforms: ${platforms}. Niche: ${niche}. Goal: ${goal}.
Output exactly:
1) Five post drafts with hook/body/CTA/platform/suggested posting window.
2) Three genuine reply templates.
3) One lead magnet concept tied to the goal.
4) One monetization action for this week.
5) Five metrics to check in 7 days.
6) One thing to stop doing.
Use the Social Operator guardrails in the system prompt. Never invent data.`;
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,30);
      const context=[SYSTEM,`\nSOCIAL OPERATOR MODE:\n${await fs.readFile(path.join(ROOT,'prompts','social-operator.md'),'utf8')}`,`\nMEMORY:\n${memories.map(x=>'- '+x.text).join('\n')||'(none)'}`].join('\n');
      try{
        const m=await onlineModel([{role:'system',content:context},{role:'user',content:prompt}]);
        if(m.ok){ const generatedAt=new Date().toISOString(); await saveConversation({id:crypto.randomUUID(),type:'social-cycle',platforms,niche,goal,text:m.text,createdAt:generatedAt}); return json(res,200,{ok:true,mode:'online-model',platforms,niche,goal,text:m.text,generatedAt}); }
      }catch(e){ return json(res,502,{ok:false,error:e.message}); }
      return json(res,503,{ok:false,error:'MODEL_NOT_CONFIGURED',message:'Configure AURA_MODEL_URL and AURA_MODEL_KEY to run the online social cycle.'});
    }
    if(req.method==='GET' && u.pathname==='/api/search'){
      const q=(u.searchParams.get('q')||'').trim(); if(!q) return json(res,400,{error:'q required'}); const results=await webSearch(q); return json(res,200,{query:q,results});
    }
    if(req.method==='POST' && u.pathname==='/api/chat'){
      const b=await body(req); const message=String(b.message||'').trim(); if(!message) return json(res,400,{error:'message required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,30);
      let web=[]; if(b.web===true) { try{web=await webSearch(message);}catch(e){web=[{error:e.message}];} }
      const context=[SYSTEM,`\nMEMORY:\n${memories.map(x=>'- '+x.text).join('\n')||'(none)'}`,`\nWEB RESULTS:\n${web.map(x=>`- ${x.title||''} ${x.url||''}`).join('\n')||'(not requested)'}`].join('\n');
      const messages=[{role:'system',content:context}];
      if(Array.isArray(b.history)) for(const x of b.history.slice(-12)){ if(x&&['user','assistant'].includes(x.role)) messages.push({role:x.role,content:String(x.content||'').slice(0,12000)}); }
      messages.push({role:'user',content:message});
      try{
        const m=await onlineModel(messages); if(m.ok){ await saveConversation({id:crypto.randomUUID(),type:'chat',message,text:m.text,web,createdAt:new Date().toISOString()}); return json(res,200,{ok:true,mode:'online-model',text:m.text,web}); }
      }catch(e){ return json(res,502,{ok:false,mode:'model-error',error:e.message,web}); }
      const fallback=`Online brain is connected to Aura's memory and web-search layer, but no model endpoint is configured yet. Add AURA_MODEL_URL and AURA_MODEL_KEY on the server to enable full reasoning.\n\nI can still access ${memories.length} saved memories and ${web.length} web results for this request.`;
      return json(res,200,{ok:true,mode:'online-tools-only',text:fallback,web});
    }
    if(req.method==='GET'){
      const file=safePath(u.pathname); if(!file) return text(res,403,'Forbidden');
      try{ const buf=await fs.readFile(file); const ext=path.extname(file); const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'}; text(res,200,buf,types[ext]||'application/octet-stream'); }
      catch{ text(res,404,'Not found'); }
      return;
    }
    json(res,404,{error:'not found'});
  }catch(e){json(res,500,{error:e.message});}
}

http.createServer(handle).listen(PORT,HOST,()=>console.log(`Aura Online Brain ${BUILD_VERSION} listening on http://${HOST}:${PORT}`));
