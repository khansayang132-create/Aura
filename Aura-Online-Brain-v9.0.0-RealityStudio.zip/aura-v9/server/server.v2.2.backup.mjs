import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { URL } from 'node:url';

const ROOT = path.resolve(new URL('..', import.meta.url).pathname);
const DATA = path.join(ROOT, 'data');
const WWW = ROOT;
const PORT = Number(process.env.PORT || 8787);
const MODEL_URL = process.env.AURA_MODEL_URL || '';
const MODEL_KEY = process.env.AURA_MODEL_KEY || '';
const MODEL_NAME = process.env.AURA_MODEL_NAME || 'online-model';
const MAX_BODY = 1_000_000;

await fs.mkdir(DATA, {recursive:true});
for (const [name, initial] of [['memory.json', []], ['conversations.json', []]]) {
  try { await fs.access(path.join(DATA,name)); } catch { await fs.writeFile(path.join(DATA,name), JSON.stringify(initial,null,2)); }
}

const json = (res, code, data) => { res.writeHead(code, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'}); res.end(JSON.stringify(data)); };
const text = (res, code, body, type='text/plain; charset=utf-8') => { res.writeHead(code, {'content-type':type}); res.end(body); };
const readJson = async file => JSON.parse(await fs.readFile(file,'utf8'));
const writeJson = async (file, value) => { const tmp=file+'.tmp'; await fs.writeFile(tmp,JSON.stringify(value,null,2)); await fs.rename(tmp,file); };
const body = req => new Promise((resolve,reject)=>{ let s=''; req.on('data',c=>{s+=c;if(s.length>MAX_BODY){req.destroy();reject(new Error('body too large'));}}); req.on('end',()=>{try{resolve(JSON.parse(s||'{}'));}catch(e){reject(e);}}); req.on('error',reject); });

function safePath(urlPath){
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  const rel = decoded === '/' ? '/index.html' : decoded;
  const full = path.resolve(WWW, '.'+rel);
  if (!full.startsWith(WWW+path.sep) && full!==WWW) return null;
  return full;
}

function extractModelText(data){
  if (typeof data?.output_text === 'string') return data.output_text;
  if (typeof data?.response === 'string') return data.response;
  if (typeof data?.message === 'string') return data.message;
  if (Array.isArray(data?.choices)) return data.choices.map(c => c?.message?.content ?? c?.text ?? '').join('\n').trim();
  if (Array.isArray(data?.output)) return data.output.flatMap(x=>x?.content||[]).map(x=>x?.text||'').join('\n').trim();
  return '';
}

async function onlineModel(messages){
  if (!MODEL_URL) return {ok:false, reason:'MODEL_NOT_CONFIGURED'};
  const headers={'content-type':'application/json'};
  if(MODEL_KEY) headers.authorization=`Bearer ${MODEL_KEY}`;
  const payload={model:MODEL_NAME,messages,temperature:0.2};
  const r=await fetch(MODEL_URL,{method:'POST',headers,body:JSON.stringify(payload)});
  const raw=await r.text();
  let data; try{data=JSON.parse(raw);}catch{data={raw};}
  if(!r.ok) throw new Error(`Model HTTP ${r.status}: ${typeof data?.error==='string'?data.error:raw.slice(0,500)}`);
  const out=extractModelText(data);
  if(!out) throw new Error('Model returned no text');
  return {ok:true,text:out,raw:data};
}

function stripTags(s){return s.replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&#x27;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();}
async function webSearch(q){
  const u='https://html.duckduckgo.com/html/?q='+encodeURIComponent(q);
  const r=await fetch(u,{headers:{'user-agent':'Aura-Online-Brain/2.0'}});
  if(!r.ok) throw new Error(`Search HTTP ${r.status}`);
  const html=await r.text();
  const out=[]; const re=/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m; while((m=re.exec(html)) && out.length<8){ out.push({title:stripTags(m[2]),url:m[1]}); }
  return out;
}

const SYSTEM=`You are Aura Online Brain, a practical autonomous assistant for the user's Aura SocialOps workspace.\nRules: be factual, concise, and transparent about uncertainty. Never fabricate live data, prices, links, analytics, actions, or tool results. Use supplied memory and web results as context, not as unquestionable truth. If a tool is unavailable, say so. Prefer actionable steps. The user remains in control of external actions.`;

function clampText(v,max=12000){ return String(v??'').slice(0,max); }
function tokenize(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9\s#@._-]/g,' ').split(/\s+/).filter(Boolean); }
function overlap(a,b){ const A=new Set(tokenize(a)), B=new Set(tokenize(b)); if(!A.size||!B.size) return 0; let n=0; for(const x of A) if(B.has(x)) n++; return n/Math.max(1,Math.min(A.size,B.size)); }
function smartSignals(memories){
  const texts=memories.map(x=>x.text||'');
  const joined=texts.join('\n');
  const asks=texts.filter(t=>/[?]$|\b(how|what|which|link|price|buy|where|can you)\b/i.test(t));
  const metrics=texts.filter(t=>/\b(views?|saves?|shares?|comments?|clicks?|retention|watch time|impressions?|conversion|ctr)\b/i.test(t));
  const repeated=[];
  for(let i=0;i<texts.length;i++) for(let j=i+1;j<texts.length;j++) if(overlap(texts[i],texts[j])>=0.72) repeated.push([texts[i],texts[j]]);
  return {memoryCount:texts.length,audienceQuestions:asks.slice(0,8),metricNotes:metrics.slice(0,8),repeatedThemes:repeated.slice(0,5),recentMemory:texts.slice(0,10),tokenHints:[...new Set(tokenize(joined))].slice(0,40)};
}

async function saveConversation(record){
  const file=path.join(DATA,'conversations.json'); const items=await readJson(file); items.unshift(record); await writeJson(file,items.slice(0,500));
}

async function handle(req,res){
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try{
    if(req.method==='GET' && u.pathname==='/api/health') return json(res,200,{ok:true,online:true,modelConfigured:Boolean(MODEL_URL),searchAvailable:true,time:new Date().toISOString()});
    if(req.method==='GET' && u.pathname==='/api/brain/status'){
      const memories=await readJson(path.join(DATA,'memory.json')); const conversations=await readJson(path.join(DATA,'conversations.json'));
      return json(res,200,{ok:true,version:'2.2.0',online:true,model:{configured:Boolean(MODEL_URL),name:MODEL_NAME,urlConfigured:Boolean(MODEL_URL)},searchAvailable:true,memoryCount:memories.length,conversationCount:conversations.length,signals:smartSignals(memories),time:new Date().toISOString()});
    }
    if(req.method==='GET' && u.pathname==='/api/brain/insights'){
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,100);
      const signals=smartSignals(memories);
      return json(res,200,{ok:true,generatedAt:new Date().toISOString(),insights:[
        signals.audienceQuestions.length?`Audience questions detected: ${signals.audienceQuestions.length}`:'No audience-question evidence stored yet.',
        signals.metricNotes.length?`Metric evidence detected in ${signals.metricNotes.length} memory items.`:'No metric evidence stored yet.',
        signals.repeatedThemes.length?`Repeated themes detected: ${signals.repeatedThemes.length}`:'No repeated themes detected.'
      ],signals});
    }
    if(req.method==='GET' && u.pathname==='/api/memory') return json(res,200,{items:await readJson(path.join(DATA,'memory.json'))});
    if(req.method==='POST' && u.pathname==='/api/memory'){
      const b=await body(req); const text=String(b.text||'').trim(); if(!text) return json(res,400,{error:'text required'});
      const items=await readJson(path.join(DATA,'memory.json')); const item={id:crypto.randomUUID(),text,createdAt:new Date().toISOString(),source:String(b.source||'user').slice(0,80),tags:Array.isArray(b.tags)?b.tags.slice(0,20).map(x=>String(x).slice(0,60)):[]}; items.unshift(item); await writeJson(path.join(DATA,'memory.json'),items.slice(0,1000)); return json(res,201,item);
    }
    if(req.method==='DELETE' && u.pathname.startsWith('/api/memory/')){
      const id=u.pathname.split('/').pop(); const items=await readJson(path.join(DATA,'memory.json')); await writeJson(path.join(DATA,'memory.json'),items.filter(x=>x.id!==id)); return json(res,200,{ok:true});
    }
    if(req.method==='POST' && u.pathname==='/api/social-plan'){
      const b=await body(req); const platforms=String(b.platforms||'x,ig,tiktok').trim(); const niche=String(b.niche||'').trim(); const goal=String(b.goal||'').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,100); const signals=smartSignals(memories);
      const platformList=platforms.split(',').map(x=>x.trim()).filter(Boolean).slice(0,5);
      const plan={mode:'deterministic-planner',platforms:platformList,niche,goal,principles:['one audience problem per post','one CTA per post','use evidence before changing strategy','do not fabricate metrics or product facts'],sequence:[
        {step:1,action:'Collect evidence',check:signals.metricNotes.length?'Use stored metric notes.':'Record views, retention/watch time, saves, shares, comments and clicks after publishing.'},
        {step:2,action:'Choose the next hypothesis',check:signals.audienceQuestions.length?'Start from the strongest audience question.':'Use one clear pain point from the niche; do not invent audience demand.'},
        {step:3,action:'Publish one controlled test',check:'Change one major variable only: hook, pacing, format, or CTA.'},
        {step:4,action:'Measure at 24h and 7d',check:'Compare against the creator’s own prior evidence, not promises or universal benchmarks.'},
        {step:5,action:'Update memory',check:'Save the result and what changed so Aura can learn from the next cycle.'}
      ],signals};
      return json(res,200,{ok:true,plan,generatedAt:new Date().toISOString()});
    }
    if(req.method==='POST' && u.pathname==='/api/social-cycle'){
      const b=await body(req);
      const platforms=String(b.platforms||'x,ig,tiktok').trim();
      const niche=String(b.niche||'ai tools for solo founders').trim();
      const goal=String(b.goal||'email list + $29/mo product').trim();
      if(!platforms||!niche||!goal) return json(res,400,{error:'platforms, niche and goal are required'});
      const prompt=`Run one full social cycle. Platforms: ${platforms}. Niche: ${niche}. Goal: ${goal}.
Output exactly:
1) Five post drafts with hook/body/CTA/platform/suggested posting window.
2) Three genuine reply templates.
3) One lead magnet concept tied to the goal.
4) One monetization action for this week.
5) Five metrics to check in 7 days.
6) One thing to stop doing.
Use the Social Operator guardrails in the system prompt. Never invent data.`;
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,30);
      const context=[SYSTEM,`\nSOCIAL OPERATOR MODE:\n${await fs.readFile(path.join(ROOT,'prompts','social-operator.md'),'utf8')}`,`\nMEMORY:\n${memories.map(x=>'- '+x.text).join('\n')||'(none)'}`].join('\n');
      try{
        const m=await onlineModel([{role:'system',content:context},{role:'user',content:prompt}]);
        if(m.ok){ const generatedAt=new Date().toISOString(); await saveConversation({id:crypto.randomUUID(),type:'social-cycle',platforms,niche,goal,text:m.text,createdAt:generatedAt}); return json(res,200,{ok:true,mode:'online-model',platforms,niche,goal,text:m.text,generatedAt}); }
      }catch(e){ return json(res,502,{ok:false,error:e.message}); }
      return json(res,503,{ok:false,error:'MODEL_NOT_CONFIGURED',message:'Configure AURA_MODEL_URL and AURA_MODEL_KEY to run the online social cycle.'});
    }
    if(req.method==='GET' && u.pathname==='/api/search'){
      const q=(u.searchParams.get('q')||'').trim(); if(!q) return json(res,400,{error:'q required'}); const results=await webSearch(q); return json(res,200,{query:q,results});
    }
    if(req.method==='POST' && u.pathname==='/api/chat'){
      const b=await body(req); const message=String(b.message||'').trim(); if(!message) return json(res,400,{error:'message required'});
      const memories=(await readJson(path.join(DATA,'memory.json'))).slice(0,30);
      let web=[]; if(b.web===true) { try{web=await webSearch(message);}catch(e){web=[{error:e.message}];} }
      const context=[SYSTEM,`\nMEMORY:\n${memories.map(x=>'- '+x.text).join('\n')||'(none)'}`,`\nWEB RESULTS:\n${web.map(x=>`- ${x.title||''} ${x.url||''}`).join('\n')||'(not requested)'}`].join('\n');
      const messages=[{role:'system',content:context}];
      if(Array.isArray(b.history)) for(const x of b.history.slice(-12)){ if(x&&['user','assistant'].includes(x.role)) messages.push({role:x.role,content:String(x.content||'').slice(0,12000)}); }
      messages.push({role:'user',content:message});
      try{
        const m=await onlineModel(messages); if(m.ok){ await saveConversation({id:crypto.randomUUID(),type:'chat',message,text:m.text,web,createdAt:new Date().toISOString()}); return json(res,200,{ok:true,mode:'online-model',text:m.text,web}); }
      }catch(e){ return json(res,502,{ok:false,mode:'model-error',error:e.message,web}); }
      const fallback=`Online brain is connected to Aura's memory and web-search layer, but no model endpoint is configured yet. Add AURA_MODEL_URL and AURA_MODEL_KEY on the server to enable full reasoning.\n\nI can still access ${memories.length} saved memories and ${web.length} web results for this request.`;
      return json(res,200,{ok:true,mode:'online-tools-only',text:fallback,web});
    }
    if(req.method==='GET'){
      const file=safePath(u.pathname); if(!file) return text(res,403,'Forbidden');
      try{ const buf=await fs.readFile(file); const ext=path.extname(file); const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'}; text(res,200,buf,types[ext]||'application/octet-stream'); }
      catch{ text(res,404,'Not found'); }
      return;
    }
    json(res,404,{error:'not found'});
  }catch(e){json(res,500,{error:e.message});}
}

http.createServer(handle).listen(PORT,'127.0.0.1',()=>console.log(`Aura Online Brain listening on http://127.0.0.1:${PORT}`));
