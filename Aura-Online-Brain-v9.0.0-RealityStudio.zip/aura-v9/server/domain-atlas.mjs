// Deterministic 1,000,000-domain engineering atlas.
// Domains are generated from a finite taxonomy; rules are generated on demand.
// This avoids pretending to store a million hand-authored documents while making
// every domain addressable, searchable, inspectable and testable.

const families = [
 'Software Architecture','Frontend Engineering','Backend Engineering','Web Platform','Mobile Engineering','Android','iOS','Databases','Data Engineering','Distributed Systems',
 'Networking','Cloud Computing','DevOps','CI/CD','Security Engineering','Application Security','Identity & Access','Privacy Engineering','AI Engineering','Machine Learning',
 'LLM Systems','Data Science','Analytics','Observability','Reliability Engineering','Performance Engineering','QA Engineering','Test Automation','Release Engineering','SRE',
 'Product Engineering','UX Engineering','UI Systems','Accessibility','Design Systems','Graphics Engineering','GPU Computing','Computer Vision','Game Engineering','3D Systems',
 'Robotics','Embedded Systems','IoT','Edge Computing','Operating Systems','Compilers','Programming Languages','Developer Tools','Open Source','Documentation',
 'API Engineering','Event Systems','Messaging','Search Systems','Recommendation Systems','Commerce Systems','Payments Engineering','FinTech Systems','HealthTech Systems','EdTech Systems',
 'Media Systems','Streaming Systems','Audio Engineering','Video Engineering','Content Platforms','Social Platforms','Trust & Safety','Fraud Engineering','Risk Systems','Compliance Engineering',
 'Enterprise Systems','CRM Engineering','ERP Engineering','Workflow Systems','Automation Engineering','Agent Systems','Knowledge Systems','Decision Systems','Simulation','Digital Twins',
 'Scientific Computing','Numerical Computing','Geospatial Systems','GIS Engineering','Climate Systems','Energy Systems','Automotive Software','Aerospace Software','Industrial Systems','Manufacturing Software',
 'Hardware Systems','Firmware','Chip/SoC Software','Storage Systems','File Systems','Virtualization','Containers','Serverless','Infrastructure as Code','Platform Engineering'
];
const specs = ['Architecture','Runtime','Data','Interfaces','State','Concurrency','Performance','Security','Testing','Observability'];
const contexts = ['Local','Cloud','Hybrid','Edge','Offline','Online','Real-Time','Batch','Interactive','Autonomous'];
const environments = ['Production','Development','Staging','Mobile','Web','Desktop','Embedded','Distributed','Regulated','Public'];
const lifecycles = ['Discovery','Requirements','Design','Implementation','Integration','Verification','Hardening','Deployment','Operations','Recovery'];
const ruleKinds = [
 ['requirements','Define measurable functional, non-functional, and operational requirements for the domain before implementation.'],
 ['boundaries','Make trust boundaries, ownership boundaries, and dependency boundaries explicit.'],
 ['interfaces','Specify stable inputs, outputs, schemas, error contracts, and compatibility expectations.'],
 ['state','Model valid states and transitions; reject impossible or ambiguous state changes.'],
 ['failure','Define failure modes, timeouts, retries, fallback behavior, and safe degradation.'],
 ['security','Apply least privilege, secret isolation, validation, and secure-by-default behavior.'],
 ['privacy','Minimize sensitive data collection, retention, exposure, and unnecessary propagation.'],
 ['performance','Measure the relevant latency, throughput, memory, CPU, storage, or network cost before optimizing.'],
 ['concurrency','Make ownership, ordering, idempotency, locking, and race behavior explicit where concurrency exists.'],
 ['data','Validate data shape, provenance, freshness, consistency, and migration behavior.'],
 ['observability','Expose actionable logs, metrics, traces, health signals, and correlation identifiers.'],
 ['testing','Create executable tests for normal paths, boundary cases, failure paths, and regressions.'],
 ['accessibility','Ensure user-facing behavior remains keyboard, screen-reader, touch, contrast, and reduced-motion aware where applicable.'],
 ['compatibility','Define supported runtimes, versions, devices, browsers, protocols, and backward-compatibility rules.'],
 ['deployment','Make builds reproducible and record artifact identity, configuration, and environment assumptions.'],
 ['rollback','Provide a tested rollback, recovery, or forward-fix path for production changes.'],
 ['resilience','Design for dependency loss, partial failure, degraded connectivity, and restart/recovery.'],
 ['cost','Track material infrastructure, API, storage, compute, and operational costs.'],
 ['documentation','Document decisions, assumptions, operational procedures, and known limitations.'],
 ['verification','Verify the actual running artifact rather than relying only on source inspection.'],
 ['change-control','Keep changes small, reviewable, reversible, and traceable to a requirement or defect.'],
 ['evidence','Separate observed evidence from assumptions, forecasts, and heuristics.'],
 ['learning','Capture defects, outcomes, measurements, and decisions as durable feedback for the next iteration.'],
 ['governance','Define ownership, approval, auditability, retention, and escalation requirements appropriate to the domain.']
];

export const ATLAS_VERSION='8.0.0-1000000Domain';
export const DOMAIN_COUNT=families.length*specs.length*contexts.length*environments.length*lifecycles.length;
export const RULES_PER_DOMAIN=ruleKinds.length;

function idParts(n){
 let x=n; const l=x%lifecycles.length; x=Math.floor(x/lifecycles.length);
 const e=x%environments.length; x=Math.floor(x/environments.length);
 const c=x%contexts.length; x=Math.floor(x/contexts.length);
 const s=x%specs.length; x=Math.floor(x/specs.length);
 const f=x%families.length;
 return {f,s,c,e,l};
}
export function domainAt(index){
 if(!Number.isInteger(index)||index<0||index>=DOMAIN_COUNT) return null;
 const p=idParts(index);
 const domainId=`A8-${String(index+1).padStart(7,'0')}`;
 return {domainId,index,domain:`${families[p.f]} — ${specs[p.s]} — ${contexts[p.c]} — ${environments[p.e]} — ${lifecycles[p.l]}`,family:families[p.f],specialization:specs[p.s],context:contexts[p.c],environment:environments[p.e],lifecycle:lifecycles[p.l]};
}
export function rulesForDomain(domain){
 if(!domain) return [];
 return ruleKinds.map(([category,base],i)=>({id:`${domain.domainId}-R${String(i+1).padStart(2,'0')}`,domainId:domain.domainId,domain:domain.domain,category,rule:`${base} In ${domain.domain}, prioritize evidence from ${domain.lifecycle.toLowerCase()} work in the ${domain.environment.toLowerCase()} environment and account for ${domain.context.toLowerCase()} operating conditions.`,verification:`Verify with a domain-specific executable check, measurement, review, or controlled test; record the observed result.`}));
}
export function findDomains(q,limit=25){
 const terms=String(q||'').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean); if(!terms.length) return [];
 const out=[]; const max=DOMAIN_COUNT;
 for(let i=0;i<max;i++){
   const d=domainAt(i); const hay=d.domain.toLowerCase(); let score=0; for(const t of terms) if(hay.includes(t)) score++;
   if(score) out.push({...d,score});
 }
 return out.sort((a,b)=>b.score-a.score || a.index-b.index).slice(0,limit);
}
export function domainById(id){
 const m=String(id||'').match(/^A8-(\d{1,7})$/); if(!m) return null; return domainAt(Number(m[1])-1);
}
export function randomSample(n=10){
 const out=[]; let seed=0x9e3779b9;
 for(let i=0;i<n;i++){seed=(seed*1664525+1013904223)>>>0; out.push(domainAt(seed%DOMAIN_COUNT));}
 return out;
}
export const taxonomy={families,specs,contexts,environments,lifecycles};
