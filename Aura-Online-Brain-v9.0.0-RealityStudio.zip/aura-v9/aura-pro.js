(()=>{
  'use strict';
  const pages={'/':'Vision Hub','/index.html':'Vision Hub','/operator.html':'Operator','/omnimind.html':'OmniMind','/engineering.html':'Engineering','/mission.html':'Mission Control','/vision.html':'Vision Hub','/showcase.html':'Reality Gallery'};
  const current=pages[location.pathname]||'Operator';
  const links=[['/','✦','Vision Hub'],['/operator.html','◉','Operator'],['/omnimind.html','ϟ','OmniMind'],['/engineering.html','⌘','Engineering'],['/mission.html','◈','Mission Control'],['/showcase.html','▣','Reality Gallery']];
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  document.documentElement.classList.add('aura-pro-ready'); document.body.classList.add('aura-pro');

  const nav=document.createElement('aside'); nav.className='aura-pro-nav';
  nav.innerHTML=`<div class="aura-pro-brand"><div class="aura-pro-logo">✦</div><div><b>Aura</b><span>PRO MAX / 100X</span></div></div><div class="aura-pro-navlabel">Workspace</div>${links.map(([u,i,l])=>`<a class="aura-pro-link ${current===l?'active':''}" href="${u}"><span class="aura-pro-icon">${i}</span><span>${l}</span></a>`).join('')}<div class="aura-pro-navlabel">System</div><a class="aura-pro-link" href="#" data-command><span class="aura-pro-icon">⌕</span><span>Command Center</span></a><a class="aura-pro-link" href="#" data-theme><span class="aura-pro-icon">◐</span><span>Appearance</span></a><a class="aura-pro-link" href="#" data-refresh><span class="aura-pro-icon">↻</span><span>Refresh state</span></a><div class="aura-pro-navfoot"><div class="aura-pro-mini"><span>System</span><span data-global-status>checking</span></div><div class="aura-pro-mini"><span>Version</span><span>9.0 / Reality</span></div></div>`;
  document.body.prepend(nav);
  const top=document.createElement('header'); top.className='aura-pro-top'; top.innerHTML=`<div class="aura-pro-top-title"><b>${current}</b><span> / Aura operating surface</span></div><div class="aura-pro-tools"><span class="aura-live-pill"><i></i><span data-global-status>checking</span></span><button class="aura-pro-tool" data-command>⌕ <span>Command</span> <kbd>⌘K</kbd></button><button class="aura-pro-tool" data-theme>◐ <span>Theme</span></button></div>`; document.body.prepend(top);
  let main=document.querySelector('.aura-pro-main'); const existingMain=document.querySelector('main');
  if(!main && existingMain){main=document.createElement('div');main.className='aura-pro-main';existingMain.parentNode.insertBefore(main,existingMain);main.appendChild(existingMain)}
  if(!main){main=document.createElement('div');main.className='aura-pro-main';const children=[...document.body.children].filter(x=>!x.classList.contains('aura-pro-nav')&&!x.classList.contains('aura-pro-top'));children.forEach(x=>main.appendChild(x));document.body.appendChild(main)}
  const mobile=document.createElement('nav'); mobile.className='aura-mobile-bar'; mobile.innerHTML=links.map(([u,i,l])=>`<a class="${current===l?'active':''}" href="${u}"><b>${i}</b><span>${l}</span></a>`).join(''); document.body.appendChild(mobile);

  const modal=document.createElement('div'); modal.className='aura-command'; modal.innerHTML=`<div class="aura-command-box" role="dialog" aria-modal="true" aria-label="Aura command center"><div class="aura-command-head"><div><b>Command Center</b><span>Navigate, act, inspect</span></div><kbd>ESC</kbd></div><input id="auraCommandInput" aria-label="Search commands" autocomplete="off" placeholder="Search surfaces, actions or pages…"><div class="aura-command-list">${links.map(([u,i,l])=>`<a href="${u}" data-cmd="${l.toLowerCase()}">${i} <span>${l}</span><em>Open</em></a>`).join('')}<button type="button" data-refresh data-cmd="refresh reload state">↻ <span>Refresh system state</span><em>Action</em></button><button type="button" data-theme data-cmd="theme appearance dark light">◐ <span>Toggle appearance</span><em>Action</em></button><button type="button" data-top data-cmd="top dashboard home">↑ <span>Back to top</span><em>Action</em></button></div></div>`; document.body.appendChild(modal);
  const open=()=>{modal.classList.add('open');const input=$('#auraCommandInput');input.value='';filterCommands('');setTimeout(()=>input.focus(),20)}; const close=()=>modal.classList.remove('open');
  const filterCommands=q=>$$('.aura-command-list [data-cmd]',modal).forEach(x=>x.hidden=q && !(x.dataset.cmd||'').includes(q.toLowerCase()));
  $('[data-command]'); $$( '[data-command]' ).forEach(x=>x.addEventListener('click',e=>{e.preventDefault();open()})); modal.addEventListener('click',e=>{if(e.target===modal)close();const refresh=e.target.closest('[data-refresh]');if(refresh){e.preventDefault();location.reload()}const theme=e.target.closest('[data-theme]');if(theme){e.preventDefault();themeToggle();close()}const topBtn=e.target.closest('[data-top]');if(topBtn){e.preventDefault();window.scrollTo({top:0,behavior:'smooth'});close()}});
  $('#auraCommandInput',modal).addEventListener('input',e=>filterCommands(e.target.value));
  document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();open()}if(e.key==='Escape')close()});
  function themeToggle(){const light=document.documentElement.getAttribute('data-aura-theme')==='light';document.documentElement.setAttribute('data-aura-theme',light?'dark':'light');localStorage.setItem('aura.theme',light?'dark':'light');announce(light?'Dark appearance enabled':'Light appearance enabled')}
  $$( '[data-theme]' ).forEach(x=>x.addEventListener('click',e=>{e.preventDefault();themeToggle()})); const saved=localStorage.getItem('aura.theme'); if(saved)document.documentElement.setAttribute('data-aura-theme',saved);
  $$( '[data-refresh]' ).forEach(x=>x.addEventListener('click',e=>{e.preventDefault();location.reload()}));
  $$('.card,section,.aura-module,.aura-vision-hero').forEach((x,i)=>{x.classList.add('aura-reveal');x.style.animationDelay=Math.min(i*35,420)+'ms'});

  const toast=document.createElement('div');toast.className='aura-toast';toast.setAttribute('role','status');document.body.appendChild(toast);let toastTimer;
  function announce(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2200)}
  window.AuraPro={announce,themeToggle,current};
  document.addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn)return;if(btn.dataset.busy==='1')return; if(btn.textContent.trim().match(/^(Run|Search|Generate|Route|Multi-model|Save|Inspect|Refresh|Log|Copy)/)){btn.classList.add('aura-click');setTimeout(()=>btn.classList.remove('aura-click'),220)}});

  async function systemState(){try{const r=await fetch('/api/health',{cache:'no-store'});const d=await r.json();const label=d.ok?'online':'degraded';$$('[data-global-status]').forEach(x=>x.textContent=label);document.body.dataset.auraState=label;return d}catch{$$('[data-global-status]').forEach(x=>x.textContent='offline');document.body.dataset.auraState='offline';return null}}
  systemState();
})();
