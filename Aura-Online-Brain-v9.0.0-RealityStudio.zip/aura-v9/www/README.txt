Aura PWA deployment folder

Deploy this folder as a static site (for example with Netlify Drop).
Open /operator.html for the Smart Operator.
The service worker caches operator.html and the app shell after the first successful HTTPS load.

Important: the browser UI calls /api/cycle. A static-only Netlify Drop deployment does not provide that API endpoint.
For the REAL online Aura cycle, serve the frontend from the Aura Node server or configure a compatible /api/cycle backend/proxy.
Offline mode can still load the cached UI, but generation requires the backend unless you add a client-side engine.
