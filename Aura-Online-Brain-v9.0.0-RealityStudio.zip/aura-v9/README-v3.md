# Aura Online Brain v3.0 HyperCore

Offline-first, deployable online, and honest about the model boundary.

### Major upgrades
- `/api/cycle` alias + adaptive-cycle engine.
- PWA auto-fallback: configured backend -> same-origin backend -> local deterministic engine.
- Optional backend URL saved in localStorage.
- Node host binding for Railway/Render/Fly.
- CORS + OPTIONS + request IDs + lightweight rate limiting.
- `/api/diagnostics` runtime inspection.
- Memory/conversation backup export/import.
- Netlify Function for `/api/cycle`.
- Railway + Render deployment manifests.
- Server-only model secrets.

### Capability boundary
Without `AURA_MODEL_URL`, Aura does not pretend to be an LLM. It uses the deterministic evidence engine.

### Local
`npm start` then open `/operator.html`.

### Netlify
Deploy the repo with `netlify.toml` to enable the Function, or publish `www/` for static PWA. Static-only hosting still uses the local fallback.

### External backend
Enter the backend base URL in the operator's API field, e.g. `https://your-aura-api.example.com`.

### Verification
`npm test`
`npm start`
`curl -fsS http://127.0.0.1:8787/api/health`
`curl -fsS http://127.0.0.1:8787/api/diagnostics`
